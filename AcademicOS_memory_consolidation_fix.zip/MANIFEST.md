# AcademicOS — Memory-Consolidation Determinism Fix

Root cause: canonical selection in memory consolidation was not a total order;
wall-clock `AuditFields.created_at` could tie; on a tie the winner was decided
by `max()` iteration order (accidental UUID lexical order), making
`test_recall_after_consolidation_returns_only_the_canonical` nondeterministic.

Fix:
1. `backend/app/domain/value_objects/audit.py` — `_utcnow()` is now strictly
   monotonic and thread-safe (module lock; never returns an identical instant
   for consecutive in-process calls). Root-cause fix: sequential creations get
   strictly increasing `created_at`.
2. `backend/app/application/services/memory_consolidation.py` — canonical
   selection now includes object ID as a final deterministic total-order
   tiebreak (created_at always dominates it). Defense-in-depth for residual
   cross-process ties.
3. `backend/app/tests/unit/test_memory_consolidation.py` — added focused
   regression tests: `test_audit_created_at_is_strictly_monotonic` and
   `test_canonical_selection_is_deterministic_on_timestamp_tie`.

The existing assertion
`test_recall_after_consolidation_returns_only_the_canonical`
(`== [str(second.id)]`) is UNCHANGED (not weakened).

L0 boundary untouched. No L1/PDF/OCR/planner/retrieval changes.
