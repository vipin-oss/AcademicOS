# Timeout Fix — Change Report

## A. Root cause
The frontend `DEFAULT_TIMEOUT_MS = 15_000` (15 seconds) fired before Ollama
finished generating (~11.4s direct + retrieval/context overhead = >15s total).
The backend provider timeout (30s) was also tight for local CPU inference.

## B. Fix
- `client.ts`: Added `DEFAULT_AI_TIMEOUT_MS = 120_000` (120 seconds)
- `ai.ts`: AI client functions pass `timeoutMs: DEFAULT_AI_TIMEOUT_MS`
- `chat/page.tsx`: Distinguishes timeout/404/network/provider errors
- `.env.example`: Provider JSON includes `timeout_seconds: 120`
- Regular API calls still use the 15s default — only AI calls use 120s

## C. Files changed (4)
1. frontend/src/lib/api/client.ts
2. frontend/src/lib/api/ai.ts
3. frontend/src/app/(main)/chat/page.tsx
4. backend/.env.example

## D. Tests passed
- Backend: 1591 passed, 2 skipped, 0 failed
- Frontend: 76 passed
- Build: success
- TypeScript: exit 0
