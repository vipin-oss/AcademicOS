# APPLY STEPS — AcademicOS AI Timeout Fix

## PowerShell — copy and paste ALL of this:

```powershell
cd E:\AcademicOS

# --- Extract ---
Expand-Archive academicOS-timeout-fix.zip -DestinationPath C:\temp\timeoutfix

# --- Copy frontend files ---
Copy-Item "C:\temp\timeoutfix\academicOS-timeout-fix\files\frontend\src\lib\api\client.ts" "frontend\src\lib\api\client.ts" -Force
Copy-Item "C:\temp\timeoutfix\academicOS-timeout-fix\files\frontend\src\lib\api\ai.ts" "frontend\src\lib\api\ai.ts" -Force
Copy-Item -LiteralPath "C:\temp\timeoutfix\academicOS-timeout-fix\files\frontend\src\app\(main)\chat\page.tsx" -Destination "frontend\src\app\(main)\chat\page.tsx" -Force

# --- Copy backend .env.example ---
Copy-Item "C:\temp\timeoutfix\academicOS-timeout-fix\files\backend\.env.example" "backend\.env.example" -Force

# --- Update your .env: add timeout_seconds to the provider JSON ---
# Find the AI_PROVIDERS_JSON line in backend\.env and add "timeout_seconds":120
# Example: the JSON should look like:
# AI_PROVIDERS_JSON=[{"provider_id":"local-ollama",...,"streaming_enabled":true,"timeout_seconds":120}]
#
# Quick PowerShell to do it automatically:
$envFile = "backend\.env"
$content = Get-Content $envFile -Raw
if ($content -match '"streaming_enabled":true\}') {
    $content = $content -replace '"streaming_enabled":true\}', '"streaming_enabled":true,"timeout_seconds":120}'
    $content | Set-Content $envFile -Encoding UTF8
    Write-Host "Added timeout_seconds=120 to AI_PROVIDERS_JSON in .env"
}

# --- Restart backend ---
# Ctrl+C in the backend terminal, then:
# cd backend
# python -m uvicorn app.main:app --reload --port 8000

# --- Test chat ---
# Open http://localhost:3000/chat and type: "Reply with exactly: AcademicOS OK"

# --- Commit and push ---
cd E:\AcademicOS
git add "frontend/src/lib/api/client.ts" "frontend/src/lib/api/ai.ts" "frontend/src/app/(main)/chat/page.tsx" backend/.env.example
git commit -m "fix: increase AI request timeout for local Ollama inference"
git push origin feature/m11-ai-workspace
```
