import { API_BASE_URL } from "@/config/env";
import { clearTokens, getAccessToken, getRefreshToken, setTokens } from "@/lib/auth/token";

/**
 * Thin fetch wrapper. No business logic — transport + error normalisation only.
 *
 * Guarantees relied on by the whole app:
 *  - every failure is an {@link ApiError} carrying the HTTP status and the
 *    *backend* message (FastAPI `detail`) whenever the server sent one;
 *  - network / offline / timeout / cancellation are distinguishable;
 *  - `Content-Type: application/json` is only sent when there IS a body, so
 *    plain GET/DELETE stay CORS-simple and skip the preflight round-trip;
 *  - 204 (and empty bodies) resolve to `undefined` instead of throwing.
 */

/** Default timeout for regular API calls (15 seconds). */
export const DEFAULT_TIMEOUT_MS = 15_000;

/**
 * Default timeout for AI generation calls (chat, QA, summarize, enrich).
 * Local CPU-based inference (Ollama, vLLM) can take 10-60+ seconds per
 * response — especially with retrieval overhead. 120 seconds gives ample
 * headroom without hanging indefinitely.
 */
export const DEFAULT_AI_TIMEOUT_MS = 120_000;

export type ApiErrorKind = "http" | "network" | "offline" | "timeout" | "aborted";

const STATUS_FALLBACK: Record<number, string> = {
  400: "The request was invalid.",
  401: "Your session has expired. Please sign in again.",
  403: "You do not have permission to perform this action.",
  404: "The requested resource was not found.",
  409: "This conflicts with the current state of the resource.",
  422: "Some of the submitted values are invalid.",
  429: "Too many requests. Please slow down and try again.",
  500: "The server encountered an unexpected error.",
  502: "The server is temporarily unavailable.",
  503: "The server is temporarily unavailable.",
  504: "The server took too long to respond.",
};

export class ApiError extends Error {
  readonly kind: ApiErrorKind;
  readonly status: number | null;
  readonly details: unknown;

  constructor(
    message: string,
    options: { kind: ApiErrorKind; status?: number | null; details?: unknown },
  ) {
    super(message);
    this.name = "ApiError";
    this.kind = options.kind;
    this.status = options.status ?? null;
    this.details = options.details;
    // Required so `instanceof` survives the ES5 downlevel target.
    Object.setPrototypeOf(this, ApiError.prototype);
  }

  get isAborted(): boolean {
    return this.kind === "aborted";
  }
  get isOffline(): boolean {
    return this.kind === "offline";
  }
  get isTimeout(): boolean {
    return this.kind === "timeout";
  }
  get isNetwork(): boolean {
    return this.kind === "network";
  }
  get isNotFound(): boolean {
    return this.status === 404;
  }
  get isConflict(): boolean {
    return this.status === 409;
  }
  get isValidation(): boolean {
    return this.status === 400 || this.status === 422;
  }
  get isAuth(): boolean {
    return this.status === 401 || this.status === 403;
  }
  /** Worth offering the user a "Try again" button. */
  get isRetryable(): boolean {
    return (
      this.kind === "network" ||
      this.kind === "offline" ||
      this.kind === "timeout" ||
      (this.status !== null && this.status >= 500)
    );
  }
}

/** Normalise anything thrown into a user-presentable string. Never silent. */
export function toErrorMessage(error: unknown, fallback = "Something went wrong."): string {
  if (error instanceof ApiError) return error.message || fallback;
  if (error instanceof Error) return error.message || fallback;
  if (typeof error === "string" && error.trim()) return error;
  return fallback;
}

/** True when the rejection is just an aborted (superseded/unmounted) request. */
export function isAbortError(error: unknown): boolean {
  if (error instanceof ApiError) return error.isAborted;
  return error instanceof DOMException && error.name === "AbortError";
}

/** Pull the most useful message out of a FastAPI error body. */
function extractMessage(body: unknown): string | null {
  if (typeof body === "string") return body.trim() || null;
  if (!body || typeof body !== "object") return null;

  const detail = (body as { detail?: unknown; message?: unknown }).detail ??
    (body as { message?: unknown }).message;

  if (typeof detail === "string") return detail.trim() || null;

  if (Array.isArray(detail)) {
    // Pydantic validation errors: [{ loc: [...], msg, type }]
    const parts = detail
      .map((entry) => {
        if (typeof entry === "string") return entry;
        if (entry && typeof entry === "object") {
          const { loc, msg } = entry as { loc?: unknown[]; msg?: string };
          const field = Array.isArray(loc)
            ? loc.filter((p) => p !== "body" && p !== "query").join(".")
            : "";
          if (field && msg) return `${field}: ${msg}`;
          if (msg) return msg;
        }
        return null;
      })
      .filter((part): part is string => Boolean(part));
    if (parts.length > 0) return parts.join("; ");
  }

  return null;
}

export interface RequestOptions {
  /** Caller-owned cancellation (component unmount, superseded request, …). */
  signal?: AbortSignal;
  /** Defaults to {@link DEFAULT_TIMEOUT_MS}. */
  timeoutMs?: number;
  headers?: HeadersInit;
  /** Serialised into the query string; `undefined` / `null` values are dropped. */
  query?: Record<string, string | number | boolean | null | undefined>;
}

function buildUrl(path: string, query?: RequestOptions["query"]): string {
  // NOTE: `path` is used verbatim. Object ids (`obj:course:AB12…`) are legal
  // path characters — encoding them here would double-encode the id and the
  // backend `ObjectId.parse` would reject `obj%3Acourse%3A…`.
  if (!query) return `${API_BASE_URL}${path}`;
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === "") continue;
    search.append(key, String(value));
  }
  const qs = search.toString();
  return qs ? `${API_BASE_URL}${path}?${qs}` : `${API_BASE_URL}${path}`;
}

async function request<T>(
  path: string,
  init: RequestInit = {},
  options: RequestOptions = {},
): Promise<T> {
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    throw new ApiError("You appear to be offline. Check your connection and try again.", {
      kind: "offline",
    });
  }

  const controller = new AbortController();
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  const external = options.signal;
  const forwardAbort = () => controller.abort();
  if (external) {
    if (external.aborted) controller.abort();
    else external.addEventListener("abort", forwardAbort);
  }

  const hasBody = init.body !== undefined && init.body !== null;
  const headers: Record<string, string> = { Accept: "application/json" };
  if (hasBody) headers["Content-Type"] = "application/json";
  attachAuthorization(headers);

  let res: Response;
  try {
    res = await fetch(buildUrl(path, options.query), {
      ...init,
      signal: controller.signal,
      headers: { ...headers, ...(options.headers as Record<string, string> | undefined) },
    });
  } catch (error) {
    if (external?.aborted) {
      throw new ApiError("Request cancelled.", { kind: "aborted" });
    }
    if (timedOut) {
      throw new ApiError(
        `The server did not respond within ${Math.round(timeoutMs / 1000)}s. Please try again.`,
        { kind: "timeout" },
      );
    }
    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      throw new ApiError("You appear to be offline. Check your connection and try again.", {
        kind: "offline",
      });
    }
    throw new ApiError(
      `Cannot reach the API at ${API_BASE_URL}. Make sure the backend is running.`,
      { kind: "network", details: error },
    );
  } finally {
    clearTimeout(timer);
    external?.removeEventListener("abort", forwardAbort);
  }

  if (res.status === 401 && !path.startsWith("/auth/") && !authRetried.has(init)) {
    // Session may have expired: try one silent refresh, then retry once.
    authRetried.add(init);
    const refreshed = await refreshSession();
    if (refreshed) return request<T>(path, init, options);
  }

  if (!res.ok) {
    let body: unknown = null;
    try {
      const text = await res.text();
      body = text ? (JSON.parse(text) as unknown) : null;
    } catch {
      /* non-JSON error body — fall back to the status message */
    }
    const message =
      extractMessage(body) ??
      STATUS_FALLBACK[res.status] ??
      `Request failed: ${res.status} ${res.statusText}`;
    throw new ApiError(message, { kind: "http", status: res.status, details: body });
  }

  if (res.status === 204 || res.headers.get("content-length") === "0") {
    return undefined as T;
  }

  const text = await res.text();
  if (!text) return undefined as T;
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new ApiError("The server returned a malformed response.", {
      kind: "http",
      status: res.status,
      details: text,
    });
  }
}

/**
 * Plain-text variant of {@link request} (Intake M2 raw extracted text).
 * Identical transport guarantees — offline/timeout/abort, status-normalised
 * `ApiError`s — but the success body is returned verbatim, never parsed.
 */
async function requestText(path: string, options: RequestOptions = {}): Promise<string> {
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    throw new ApiError("You appear to be offline. Check your connection and try again.", {
      kind: "offline",
    });
  }

  const controller = new AbortController();
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  const external = options.signal;
  const forwardAbort = () => controller.abort();
  if (external) {
    if (external.aborted) controller.abort();
    else external.addEventListener("abort", forwardAbort);
  }

  let res: Response;
  try {
    const rawHeaders: Record<string, string> = { Accept: "text/plain" };
    attachAuthorization(rawHeaders);
    res = await fetch(buildUrl(path, options.query), {
      method: "GET",
      signal: controller.signal,
      headers: rawHeaders,
    });
  } catch (error) {
    if (external?.aborted) {
      throw new ApiError("Request cancelled.", { kind: "aborted" });
    }
    if (timedOut) {
      throw new ApiError(
        `The server did not respond within ${Math.round(timeoutMs / 1000)}s. Please try again.`,
        { kind: "timeout" },
      );
    }
    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      throw new ApiError("You appear to be offline. Check your connection and try again.", {
        kind: "offline",
      });
    }
    throw new ApiError(
      `Cannot reach the API at ${API_BASE_URL}. Make sure the backend is running.`,
      { kind: "network", details: error },
    );
  } finally {
    clearTimeout(timer);
    external?.removeEventListener("abort", forwardAbort);
  }

  if (!res.ok) {
    let body: unknown = null;
    try {
      const text = await res.text();
      body = text ? (JSON.parse(text) as unknown) : null;
    } catch {
      /* non-JSON error body — fall back to the status message */
    }
    const message =
      extractMessage(body) ??
      STATUS_FALLBACK[res.status] ??
      `Request failed: ${res.status} ${res.statusText}`;
    throw new ApiError(message, { kind: "http", status: res.status, details: body });
  }

  return res.text();
}

/** Attach the bearer token when one is stored (Sprint-3 M3 — auth-scoped
 * API access: every request rides the authenticated principal). No token,
 * no header — public endpoints keep working unauthenticated. */
function attachAuthorization(headers: Record<string, string>): void {
  const token = getAccessToken();
  if (token) headers.Authorization = `Bearer ${token}`;
}

// ---------------------------------------------------------------------------
// Automatic session refresh (final release)
//
// A 401 on any authenticated endpoint triggers ONE refresh-token exchange
// (single-flight: concurrent 401s share the same exchange) and retries the
// original request once. When the refresh fails the session is cleared, so
// the app behaves as signed-out. Auth endpoints (/auth/*) are excluded —
// a wrong-password 401 must never start a refresh.
// ---------------------------------------------------------------------------
let refreshInFlight: Promise<boolean> | null = null;

async function doRefresh(): Promise<boolean> {
  const refreshToken = getRefreshToken();
  if (!refreshToken) return false;
  try {
    const res = await fetch(`${API_BASE_URL}/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
    if (!res.ok) {
      clearTokens();
      return false;
    }
    const body = (await res.json()) as AuthTokensLike;
    setTokens(body.access_token, body.refresh_token);
    return true;
  } catch {
    clearTokens();
    return false;
  }
}

interface AuthTokensLike {
  access_token: string;
  refresh_token: string;
}

function refreshSession(): Promise<boolean> {
  if (!refreshInFlight) {
    refreshInFlight = doRefresh().finally(() => {
      refreshInFlight = null;
    });
  }
  return refreshInFlight;
}

const authRetried = new WeakSet<RequestInit>();

/**
 * Raw-bytes variant of {@link request} (Sprint-3 M3 — inline document
 * preview). Identical transport guarantees (offline/timeout/abort,
 * status-normalised `ApiError`s) but the success body is returned as a
 * `Blob` — an iframe cannot send the Authorization header, so the preview
 * fetches the bytes with the token and renders them via an object URL.
 */
async function requestBlob(path: string, options: RequestOptions = {}): Promise<Blob> {
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    throw new ApiError("You appear to be offline. Check your connection and try again.", {
      kind: "offline",
    });
  }

  const controller = new AbortController();
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  const external = options.signal;
  const forwardAbort = () => controller.abort();
  if (external) {
    if (external.aborted) controller.abort();
    else external.addEventListener("abort", forwardAbort);
  }

  const rawHeaders: Record<string, string> = { Accept: "*/*" };
  attachAuthorization(rawHeaders);
  let res: Response;
  try {
    res = await fetch(buildUrl(path, options.query), {
      method: "GET",
      signal: controller.signal,
      headers: rawHeaders,
    });
  } catch (error) {
    if (external?.aborted) {
      throw new ApiError("Request cancelled.", { kind: "aborted" });
    }
    if (timedOut) {
      throw new ApiError(
        `The server did not respond within ${Math.round(timeoutMs / 1000)}s. Please try again.`,
        { kind: "timeout" },
      );
    }
    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      throw new ApiError("You appear to be offline. Check your connection and try again.", {
        kind: "offline",
      });
    }
    throw new ApiError(
      `Cannot reach the API at ${API_BASE_URL}. Make sure the backend is running.`,
      { kind: "network", details: error },
    );
  } finally {
    clearTimeout(timer);
    external?.removeEventListener("abort", forwardAbort);
  }

  if (!res.ok) {
    let body: unknown = null;
    try {
      const text = await res.text();
      body = text ? (JSON.parse(text) as unknown) : null;
    } catch {
      /* non-JSON error body — fall back to the status message */
    }
    const message =
      extractMessage(body) ??
      STATUS_FALLBACK[res.status] ??
      `Request failed: ${res.status} ${res.statusText}`;
    throw new ApiError(message, { kind: "http", status: res.status, details: body });
  }

  return res.blob();
}

export const api = {
  get: <T>(path: string, options?: RequestOptions) => request<T>(path, { method: "GET" }, options),
  /** Raw `text/plain` GET — response returned verbatim (Intake M2). */
  getText: (path: string, options?: RequestOptions) => requestText(path, options),
  /** Raw bytes GET — response returned as a Blob (Sprint-3 M3 preview). */
  getBlob: (path: string, options?: RequestOptions) => requestBlob(path, options),
  post: <T>(path: string, body?: unknown, options?: RequestOptions) =>
    request<T>(
      path,
      { method: "POST", body: body === undefined ? undefined : JSON.stringify(body) },
      options,
    ),
  put: <T>(path: string, body?: unknown, options?: RequestOptions) =>
    request<T>(
      path,
      { method: "PUT", body: body === undefined ? undefined : JSON.stringify(body) },
      options,
    ),
  delete: <T>(path: string, options?: RequestOptions) =>
    request<T>(path, { method: "DELETE" }, options),
};
